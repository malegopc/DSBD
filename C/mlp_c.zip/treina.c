/* ALGORITMO "BACKPROPAGATION" PADRAO PARA TREINAMENTO DE REDES DE PERCEPTRONS MULTICAMADAS.
   OBSERVACOES: - Antes de realizar a execucao deste programa utilize o programa "cria_rede.c".
		- Uma vez que a funcao de ativacao utilizada por este algoritmo	e' a funcao SIGMOIDE deve-se mapear os padroes
		de treinamento para o intervalo [-1,1].
		- O processo de treinamento termina quando o ERRO QUADRATICO MEDIO for menor que o erro maximo exigido.*/


#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

/*
.arq_pesos -> nome do arquivo que contem os pesos da rede (arquivo binario)
.num_layers -> numero de layers da rede
.num_neuro -> vetor contendo o numero de neuronios em cada layer
.beta -> constante que define a inclinacao da sigmoide
.fe -> constante que define o fator de escala da sigmoide
.tr -> constante que define a translacao da sigmoide
.peso -> ponteiro para um vetor de ponteiros, onde cada ponteiro aponta para o vetor de pesos de conecta um layer ao layer seguinte
*/

struct rede
{
	char arq_pesos[100];
	int num_layers, *num_neuro;
	double fe,tr,beta,**peso;
};

/*
.num_padroes -> numero de padroes de treinamento lidos
.num_entradas -> numero de entradas da rede
.num_saidas -> numero de saidas da rede
.entrada -> ponteiro para o vetor de entradas padrao da rede
.saida -> ponteiro para o vetor de saidas padrao da rede
*/

struct padrao
{
	int num_padroes,num_entradas,num_saidas;
	double *entrada, *saida;
};

/* Contador p/ o numero de passos (ou ciclos) de treinamento. */
double passos_cont;

/* Funcao que recebe como argumento o nome do arquivo que contem a rede. Aloca espaco para uma estrutura do tipo rede e inicializa essa estrutura com os dados lidos no arquivo que contem a rede. Aloca memoria para os ponteiros da estrutura e le de arquivo os pesos. Devolve o ponteiro para essa estrutura criada. */

struct rede *le_rede (nome_arq)
char nome_arq[];
{
	struct rede *new;
	FILE *arq;
	int layer,size;

/* Abre arquivo que contem a descricao da rede. */
	arq = fopen (nome_arq,"r");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n",nome_arq);
		exit(1);
	}
	
/* Aloca espaco onde sera armazenada a estrutura da rede. */
	new = (struct rede *) malloc (sizeof(struct rede));

/* Le o numero de layers da rede. */
	fscanf (arq,"%d",&(new->num_layers));
	
/* Aloca vetor que contera o numero de neuronios em cada layer da rede. */
	new->num_neuro = (int *) malloc (new->num_layers*sizeof(int));

/* Le o numero de neuronios em cada layer da rede. */
	for (layer=0; layer<new->num_layers; layer++)
		fscanf (arq,"%d",&(new->num_neuro[layer]));
	
/* Le as constantes beta, fe, tr e o nome do arquivo que contem os pesos. */
	fscanf (arq,"%lf %lf %lf",&(new->beta),&(new->fe),&(new->tr));
	fscanf (arq,"%s",new->arq_pesos);
	
/* Fecha arquivo que contem a descricao da rede. */
	fclose (arq);

/* Abre arquivo que contem os pesos da rede. */
	arq = fopen (new->arq_pesos,"rb");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n", new->arq_pesos);
		exit(1);
	}

/* Aloca vetor de ponteiros para os pesos de cada layer da rede. */
	new->peso = (double **) malloc ((new->num_layers-1)*sizeof(double *));

/* Aloca vetor de pesos para cada layer da rede e le os pesos. */
	for (layer=0; layer<new->num_layers-1; layer++)
	{
		size = (new->num_neuro[layer]+1)*new->num_neuro[layer+1];
		new->peso[layer] = (double *) malloc (size*sizeof(double));
		if (fread (new->peso[layer],sizeof(double),size,arq) == 0)
		{
			printf ("\nProblemas com a leitura do arquivo %s.\n", new->arq_pesos);
			exit (1);
		}
	}

/* Fecha arquivo de pesos. */
	fclose (arq);

	return (new);
}

/* Funcao que tem como entradas o nome do arquivo que contem os padroes de treino, o numero de entradas da rede e o numero de saidas da rede. Aloca uma estrutura do tipo padrao e inicializa suas variaveis, inclusive alocando a memoria necessaria para seus ponteiros. Le as entradas e as saidas do padrao de treino do arquivo cujo nome foi passado como parametro. Devolve um ponteiro para a estrutura criada. */

struct padrao *le_padrao (nome_arq,net)
char nome_arq[];
struct rede *net;
{
	struct padrao *new;
	FILE *arq;
	int pat,entr,said;
	double *aux_entr,*aux_said;

/* Abre arquivo com os padroes da rede. */
	arq = fopen (nome_arq,"r");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n",nome_arq);
		exit(1);
	}

/* Aloca estrutura que contera os padroes de treinamento. */
	new = (struct padrao *) malloc (sizeof(struct padrao));

/* Inicializa dados da estrutura. */
	new->num_entradas = net->num_neuro[0];
	new->num_saidas = net->num_neuro[net->num_layers-1];

/* Le o numero de padroes contidos no arquivo. */
	fscanf (arq,"%d",&(new->num_padroes));

/* Aloca vetores de que conterao os padroes de entrada e de saida. */
	aux_entr = new->entrada = (double *) malloc (new->num_entradas*new->num_padroes*sizeof(double));
	aux_said = new->saida = (double *) malloc (new->num_saidas*new->num_padroes*sizeof(double));
	
/* Le e normaliza os padroes de entrada e de saida do arquivo. */
	for (pat=0; pat<new->num_padroes; pat++)
	{
		for (entr=0; entr<new->num_entradas; entr++)
		{
			fscanf (arq,"%lf",aux_entr);
			/* Mapeia os niveis de cinza [0,255] p/ [-1,1] (no caso de imagens). 
		        *aux_entr = (2*(*aux_entr))/255 - 1; */
			aux_entr++; /* WARNING */
		}
		for (said=0; said<new->num_saidas; said++)
		{
			fscanf (arq,"%lf",aux_said);
			/* Mapeia as saidas desejadas p/ [0,1]. */
			*aux_said = (*aux_said - net->tr)/net->fe;
			aux_said ++;
		}
	}
	    

/* Fecha arquivo. */
	fclose (arq);
	return (new);
}

/* Essa rotina atualiza o arquivo que contem os pesos com os novos pesos obtidos pelo treinamento. */
int grava_pesos (net)
struct rede *net;
{
	int layer,size;
	FILE *arq;
	
/* Abre arquivo de pesos. */
	arq = fopen (net->arq_pesos,"wb");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n",net->arq_pesos);
		exit(1);
	
	}
	
/* Grava pesos no arquivo. */
	for (layer=0; layer<net->num_layers-1; layer++)
	{
		size = (net->num_neuro[layer]+1)*net->num_neuro[layer+1];
		fwrite (net->peso[layer],sizeof(double),size,arq);
	}

/* Fecha arquivo. */
	fclose (arq);
}

/* A partir das saidas dos neuronios do layer de entrada, essa funcao calcula a saida de todos os outros neuronios da rede. */
int atualiza_rede (net,saida)
struct rede *net;
double **saida;
{
	int layer,neuro_ant,neuro_pos;	
	double i,*out,*weight,*in,beta;

	beta = net->beta;

/* A partir do primeiro layer depois do layer de entrada e para cada neuronio desse layer. */
	for (layer=1; layer<net->num_layers; layer++)
	{
		out = saida[layer];
		weight = net->peso[layer-1];
		for (neuro_pos=0; neuro_pos<net->num_neuro[layer]; neuro_pos++)
		{
/* Calcule a soma da saida de cada neuronio do layer anterior vezes o peso que conecta aquele neuronio a esse. */
			i = 0;
			in = saida[layer-1];
			for (neuro_ant=0; neuro_ant<net->num_neuro[layer-1]; neuro_ant++)
			{
				i += (*in) * (*weight);
				in ++;
				weight ++;
			}
				
/* Adicione a soma anterior o bias factor */
			i += *weight;
			weight ++;
/* Calcule o valor da sigmoide no ponto calculado anteriormente. Esse sera o valor da saida. */
			*out = 1/(1+exp(-i*beta));
			out ++;
		}
	}
}

/* Calcule o erro de cada neuronio da rede e o reajuste dos pesos. */
double calcula_erros (net,pat,num_pat,saida,erro,d_weight,learn_rate)
struct rede *net;
struct padrao *pat;
int num_pat;
double **saida, **erro, **d_weight, learn_rate;
{
	int layer,neuro,cont,step;
	double *weight,*out,*padrao,*delta,*dw,aux,aux1,gama,beta, eq;

	beta = net->beta;
	out = saida[net->num_layers-1];
	padrao = &(pat->saida[pat->num_saidas*num_pat]);
	delta = erro[net->num_layers-1];
	eq = 0;

	/* Calcula o erro quadratico. */
	for (cont=0; cont<pat->num_saidas; cont++)
	{
		aux = *out;
		aux1 = *padrao - aux;
		eq = eq +(aux1*aux1);
		*delta = beta * aux1 * aux * (1-aux);
		out++;
		padrao++;
		delta++;
	}

	eq = 0.5*eq;

/* Para cada layer restante da rede (exceto o layer de entrada) calcule o erro que se propagou pela rede. */
	for (layer=net->num_layers-1; layer>1; layer--)
	{
		step = net->num_neuro[layer-1]+1;
		out = saida[layer-1];
		for (neuro=0; neuro<net->num_neuro[layer-1]; neuro++)
		{
			aux = 0;
			aux1 = *out;
			gama = learn_rate*aux1;
			weight = net->peso[layer-1]+neuro;
			delta = erro[layer];
			dw = d_weight[layer-1]+neuro;
			for (cont=0; cont<net->num_neuro[layer]; cont++)
			{
				aux += (*delta) * (*weight);
				*dw += gama * (*delta);
				delta++;
				weight += step;
				dw += step;
			}
			*(erro[layer-1] + neuro) = aux* beta* aux1* (1 - aux1);
			out++;
		}
		delta = erro[layer];
		dw = d_weight[layer-1]+neuro;
		gama = learn_rate;
		for (cont=0; cont<net->num_neuro[layer]; cont++)
		{
			*dw += gama * (*delta);
			dw += step;
			delta ++;
		}
	}

	step = net->num_neuro[0]+1;
	out = saida[0];
	for (neuro=0; neuro<net->num_neuro[0]; neuro++)
	{
		gama = (*out) * learn_rate;
		delta = erro[1];
		dw = d_weight[0]+neuro;
		for (cont=0; cont<net->num_neuro[1]; cont++)
		{
			*dw += gama * (*delta);
			delta ++;
			dw += step;
		}
		out ++;
	}
	delta = erro[1];
	dw = d_weight[0] + neuro;
	gama = learn_rate;
	for (cont=0; cont<net->num_neuro[1]; cont++)
	{
		*dw += gama * (*delta);
		dw += step;
		delta ++;
	}

/* Retorne o erro quadratico obtido no layer de saida. */
	return (eq);
}

/* Soma os reajustes de pesos calculados aos pesos atuais, atualizando-os. */
int reajusta_pesos (net,delta_peso)
struct rede *net;
double **delta_peso;
{
	int layer,size,cont;
	double *w,*dw;

	for (layer=0; layer<net->num_layers-1; layer++)
	{
		w = net->peso[layer];
		dw = delta_peso[layer];
		size = (net->num_neuro[layer]+1)*net->num_neuro[layer+1];
		for (cont=0; cont<size; cont++)
		{
	 		*w += *dw;
			w++;
			*dw = 0;
			dw++;
		}
	}
}

/* Essa funcao encarrega-se de apresentar os padroes de treinamento, calcular o erro, o reajuste dos pesos e reajusta-los, ate que o erro quadratico medio seja menor que o erro_max. Cada apresentacao de todo o padrao de treinamento conta como um passo e a cada max_passos os pesos da rede sao gravados. */
double treino (nome_rede,erro_max,learn_rate,max_passos,net,pat)
char *nome_rede;
double erro_max,learn_rate;
long int max_passos;
struct rede *net;
struct padrao *pat;
{
	double eq_acum, erro_atual, eqm,**delta_peso,*input,**saida,**erro;
	int cont,size,pat_cont;
	long int passos;

/* Aloca vetor de ponteiros para matrizes que guardarao os reajustes dos pesos entre cada dois layers. */
	delta_peso = (double **) malloc ((net->num_layers-1)*sizeof(double *));
/* Aloca matriz que guardara os reajustes dos pesos entre cada dois layers e a inicializa. */
	for (cont=0; cont<net->num_layers-1; cont++)
	{
		size = (net->num_neuro[cont]+1)*net->num_neuro[cont+1];
		delta_peso[cont] = (double *) malloc (size*sizeof(double));
		if (delta_peso[cont] == NULL) exit (1);
		for (; size>0; size--)
			*(delta_peso[cont]+size-1) = 0;
	}

	saida = (double **) malloc (net->num_layers * sizeof (double *));
	erro = (double **) malloc (net->num_layers * sizeof (double *));
	for (cont=0; cont<net->num_layers; cont++)
	{
		saida[cont] = (double *) malloc (net->num_neuro[cont] * sizeof (double));
		if (cont)
			erro[cont] = (double *) malloc (net->num_neuro[cont] * sizeof (double));
	}

	passos = passos_cont = 0;

	do
	{
		eq_acum = 0;

/* Para cada padrao de treinamento: calcula as saidas da rede e calcula os erros. */
		for (pat_cont=0; pat_cont<pat->num_padroes; pat_cont++)
		{
			input = pat->entrada+pat_cont*pat->num_entradas;
			for (cont=0; cont<pat->num_entradas; cont++)
				*(saida[0]+cont) = *(input+cont);

			atualiza_rede (net,saida);

			erro_atual = calcula_erros (net, pat, pat_cont, saida, erro, delta_peso, learn_rate);

			eq_acum = eq_acum + erro_atual;

		}

		eqm = eq_acum/pat->num_padroes;

		reajusta_pesos (net,delta_peso);

/* Conta um passo. */
		passos++;
		passos_cont++;

/* Se ja foram dados max_passos entao grava os pesos. */
		if (passos == max_passos)
		{
			passos = 0;
			printf ("Rede: %s - Passo: %.0lf - ", nome_rede, passos_cont);
			printf ("EQM: %.15lf\n", eqm);
			grava_pesos (net);
		}

	} while (eqm > erro_max);

	return (eqm);
}

main ()
{
	struct rede *net;
	struct padrao *pat;
	double erro_maximo,eqm,learn_rate,tempo_inicial,tempo_final;
	char nome_rede[100],nome_padrao[100], nome_tempo[100];
	long int max_passos;
	
	printf ("\nA rede sera treinada reajustando seus pesos apos a apresentacao de todos os padroes.\n\n");

	printf ("\nDigite o nome do arquivo que contem a rede.\n");
	scanf ("%s",nome_rede);

	printf ("\nDigite o nome do arquivo que contem os padroes de treino.\n");
	scanf ("%s",nome_padrao);

	printf ("\nDigite o learn rate desejado para treinar a rede.\n");
	scanf ("%lf",&learn_rate);

	printf ("\nDigite o erro quadratico maximo desejado.\n");
	scanf ("%lf",&erro_maximo);

	printf ("\nDigite a cada quantas iteracoes deseja gravar os pesos.\n");
	scanf ("%ld",&max_passos);

	net = le_rede (nome_rede);

	pat = le_padrao (nome_padrao, net);

	tempo_inicial = time (0);
	eqm = treino (nome_rede, erro_maximo, learn_rate, max_passos, net, pat);
	tempo_final = time (0);

	grava_pesos (net);

	printf ("\nTempo gasto no treinamento: %.0lf\n", (tempo_final-tempo_inicial));
	printf ("\nNumero de passos realizados: %.0lf\n",passos_cont);
	printf ("\nErro quadratico medio final: %.15lf\n",eqm);
	getch();

}

	
	
