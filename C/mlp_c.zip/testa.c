/* Programa que testa a rede Bakpropagation com padroes fornecidos pelo usuario (teclado). */
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h> 

struct rede
{
	char nome_pesos[100];
	int num_layers, *num_neuro;
	double beta,fe,tr,gama,**peso,**saida;
};

/* Devolve um ponteiro para a estrutura da rede lida no arquivo nome_arq. */

struct rede *le_rede (nome_arq)
char nome_arq[];
{
	struct rede *temp;
	FILE *arq;
	int cont,size;

/* Abre arquivo que contem a descricao da rede. */
	arq = fopen (nome_arq,"r");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n",nome_arq);
		exit(1);
	}
	
/* Aloca espaco onde sera armazenada a estrutura da rede. */
	temp = (struct rede *) malloc (sizeof(struct rede));
	if (temp == NULL)
	{
		printf ("\nMemoria insuficiente.\n");
		exit (1);
	}

/* Le o numero de layers da rede. */
	fscanf (arq,"%d",&(temp->num_layers));
	
/* Aloca vetor que contera o numero de neuronios em cada layer da rede. */
	temp->num_neuro = (int *) malloc (temp->num_layers*sizeof(int));
	if (temp->num_neuro == NULL)
	{
		printf ("\nMemoria insuficiente.\n");
		exit (1);
	}

/* Le o numero de neuronios em cada layer da rede. */
	for (cont=0; cont<temp->num_layers; cont++)
		fscanf (arq,"%d",&(temp->num_neuro[cont]));
	
/* Le as constantes beta, fe, tr, gama e o nome do arquivo que contem os pesos. */
	fscanf (arq,"%lf",&(temp->beta));
	fscanf (arq,"%lf",&(temp->fe));
	fscanf (arq,"%lf",&(temp->tr));
	fscanf (arq,"%s",temp->nome_pesos);
	
/* Fecha arquivo que contem a descricao da rede. */
	fclose (arq);

/* Abre arquivo que contem os pesos da rede. */
	arq = fopen (temp->nome_pesos,"rb");
	if (arq == NULL)
	{
		printf ("\nNao consegui abrir o arquivo %s.\n", temp->nome_pesos);
		exit(1);
	}

/* Aloca vetor de ponteiros para os pesos de cada layer da rede. */
	temp->peso = (double **) malloc ((temp->num_layers-1)*sizeof(double *));

/* Aloca vetor de pesos para cada layer da rede e le os pesos. */
	for (cont=0; cont<temp->num_layers-1; cont++)
	{
		size = (temp->num_neuro[cont]+1)*temp->num_neuro[cont+1];
		temp->peso[cont] = (double *) malloc (size*sizeof(double));
		if (temp->peso[cont] == NULL) exit (1);
		fread (temp->peso[cont],sizeof(double),size,arq);
	}

	temp->saida = (double **) malloc (temp->num_layers*sizeof(double *));
	for (cont=0; cont<temp->num_layers; cont++)
		temp->saida[cont] = (double *) malloc (temp->num_neuro[cont]*sizeof(double));

/* Fecha arquivo de pesos. */
	fclose (arq);

	return (temp);
}

/* A partir das saidas dos neuronios do layer de entrada, essa funcao calcula a saida de todos os outros neuronios da rede. */
int atualiza_rede (net)
struct rede *net;
{
	int layer,neuro,cont,step;	
	double i,*out,*weight;

/* A partir do primeiro layer depois do layer de entrada e para cada neuronio desse layer. */
	for (layer=1; layer<net->num_layers; layer++)
	{
		weight = net->peso[layer-1];
		for (neuro=0; neuro<net->num_neuro[layer]; neuro++)
		{
/* Calcule a soma da saida de cada neuronio do layer anterior vezes o peso que conecta aquele neuronio a esse. */
			i = 0;
			out = net->saida[layer-1];
			for (cont=0; cont<net->num_neuro[layer-1]; cont++)
			{
				i += (*out) * (*weight);
				out ++;
				weight ++;
			}
				
/* Adicione a soma anterior o bias factor */
			i += *weight;
			weight ++;
/* Calcule o valor da sigmoide no ponto calculado anteriormente. Esse sera o valor da saida. */
			*(net->saida[layer]+neuro) = 1/(1+exp(-i*net->beta));
		}
	}
}

main ()
{
	int neuro;
	double *aux;
	struct rede *net;
	char nome_rede[100];

	printf ("\nDigite o nome do arquivo que contem a rede.\n");
	scanf ("%s",nome_rede);

	net = le_rede (nome_rede);

	do
	{
		printf ("\nDigite a(s) %d entrada(s).\n",net->num_neuro[0]);
		aux = net->saida[0];
		for (neuro=0; neuro<net->num_neuro[0]; neuro++)
		{
			scanf ("%lf",aux);
			aux++;
		}

		atualiza_rede (net);
		
		printf ("\nAs saidas sao:\n");
		aux = net->saida[net->num_layers-1];
		for (neuro=0; neuro<net->num_neuro[net->num_layers-1]; neuro++)
		{
			printf ("%lf",net->fe*(*aux)+net->tr);
			aux++;
		}
		printf ("\n");
	} while (1);	

}
	
