/* Programa que cria  os parametros e os pesos da rede.
  OBS: Os pesos sao gerados dentro do intervalo [-1,1]. */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>

struct rede
{
	char nome_pesos[100];
	int num_layers, *num_neuro;
	double beta,fe,tr,**peso;
};

main()
{
	FILE *arq;
	struct rede net;
	double *w,*in,*out,min,max;
	int layer,neuro,neuro1;
	int max_rand,aleat;
	time_t seed;
	char nome_rede[100];

	printf ("\nDigite o nome do arquivo que contera a rede.\n");
	scanf ("%s",nome_rede);
	printf ("\nDigite a inclinacao da sigmoide (beta).\n");
	scanf ("%lf",&(net.beta));
	printf ("\nDigite o valor maximo assumido pela saida da rede.\n");
	scanf ("%lf",&max);
	printf ("\nDigite o valor minimo assumido pela saida da rede.\n");
	scanf ("%lf",&min);
	printf ("\nDigite o numero de layers da rede (incluindo layers de entrada e de saida).\n");
	scanf ("%d",&(net.num_layers));

	net.fe = max-min;
	net.tr = min;
	net.num_neuro = (int *) malloc (net.num_layers*sizeof(int));
	net.peso = (double **) malloc (net.num_layers*sizeof(double *));
	
	printf ("\nDigite o numero de neuronios em cada layer (da entrada p/ saida).\n");
	for (layer=0; layer<net.num_layers; layer++)
	{
		printf("layer %d : ",layer+1);
		scanf("%d",&(net.num_neuro[layer]));
	}
	
	for (layer=0; layer<net.num_layers-1; layer++)
		net.peso[layer] = (double *) malloc ((net.num_neuro[layer]+1) * net.num_neuro[layer+1] * sizeof(double));

	printf ("\nDigite o nome do arquivo onde serao gravados os pesos.\n");
	scanf ("%s",net.nome_pesos);
	
	arq = fopen (nome_rede,"w");
	if (arq == NULL)
	{
		printf ("Nao consegui criar o arquivo %s.\n",nome_rede);
		exit (1);
	}

	fprintf (arq,"%d\n",net.num_layers);

	for (layer=0; layer<net.num_layers; layer++)
		fprintf (arq,"%d ",net.num_neuro[layer]);

	fprintf (arq,"%lf %lf %lf\n",net.beta,net.fe,net.tr);
	fprintf (arq,"%s\n",net.nome_pesos);
	
	fclose (arq);

	arq = fopen (net.nome_pesos,"wb");
	if (arq == NULL)
	{
		printf ("Nao consegui criar o arquivo %s.\n",nome_rede);
		exit (1);
	}
	seed = (int) time (0);
	srand (seed);
	max_rand = rand ();
	for (layer=0; layer<net.num_layers-1; layer++)
	{
		for (neuro=0; neuro<=net.num_neuro[layer]; neuro++)
		{
			w = net.peso[layer]+neuro*net.num_neuro[layer+1];
			for (neuro1=0; neuro1<net.num_neuro[layer+1]; neuro1++)
			{
				aleat = rand();
				while (aleat > max_rand)
				{
					max_rand = aleat;
					aleat = rand();
				}
				*(w+neuro1) = (2.0*aleat)/max_rand - 1;
			}
		}
		neuro = (net.num_neuro[layer]+1)*net.num_neuro[layer+1];
		fwrite ((char *)net.peso[layer],sizeof(double),neuro,arq);
	}

	fclose (arq);
 }


